const L = 1352;
const X = Math.floor(L / 100);

console.log(X);