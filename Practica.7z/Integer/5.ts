const A = 30;
const B = 4;
const X = A % B;

console.log(X);