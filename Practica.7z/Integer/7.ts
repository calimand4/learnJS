const a = 27;
const b = Math.floor(a / 10);
const c = a % 10;
const X = b + c;
const Y = b * c;

console.log(X , Y);