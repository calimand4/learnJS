const a = 123;
const X = Math.floor(a / 100);

console.log(X);