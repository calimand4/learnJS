const a = 17;
const X = Math.floor(a / 10);
const Y = a % 10;

console.log(X , Y);