const a = 123;
const stringA = a.toString( );
const arrayStringA = stringA.split('')
const reverseArray = arrayStringA.reverse( )


console.log(reverseArray[0] + " " +reverseArray[1])