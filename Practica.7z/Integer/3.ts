const K = 2408524;
const X = Math.floor(K / 1024);

console.log(X);