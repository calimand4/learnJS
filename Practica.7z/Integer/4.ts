const A = 25;
const B = 4;
const X = Math.floor(A / B);

console.log(X);