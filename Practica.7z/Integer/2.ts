const M = 184224;
const X = Math.floor(M / 1000);

console.log(X);