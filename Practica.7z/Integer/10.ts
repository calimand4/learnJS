const a = 123;
const X = a % 10;
const Y = Math.floor(a % 100);
const Z = Math.floor(Y / 10);
console.log(X,Z,);