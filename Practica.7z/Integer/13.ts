const a = 123;
const stringA = a.toString( );
const arrayStringA = stringA.split('')
const joinArray = arrayStringA.join('')
const X = joinArray[1] + joinArray[2] + joinArray[0];

console.log(X);
