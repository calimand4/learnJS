const a = 5;
const b = 3;
const c = 8;
const res = (a > 0) && (b > 0) && (c > 0);

console.log(res);