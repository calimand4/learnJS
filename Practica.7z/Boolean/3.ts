const a = 18;
const res = a % 2 == 0;

console.log(res);