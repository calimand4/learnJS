const A = 4;
const B = -3;
const res = A >= 0;
const res1 = B < -2;

console.log(res , res1);