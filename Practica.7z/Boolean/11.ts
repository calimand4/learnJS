const a = 5;
const b = 3;
const res = (a + b) % 2 == 0;

console.log(res);