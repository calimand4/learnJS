const A = 4;
const B = 5;
const C = 6;
//A < B < C
const res = (B - A) > 0;
const res1 = (C - B) > 0;

console.log(res === true && res1 === true)