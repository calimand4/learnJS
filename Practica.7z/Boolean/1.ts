const A = 25;
const res = A > 0;

console.log(res);