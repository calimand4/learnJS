const A = 21;
const B = 13;
const res = A % 2 == 1;
const res1 = B % 2 == 1;

console.log(res === true && res1 === true)