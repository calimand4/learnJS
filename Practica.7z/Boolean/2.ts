const a = 21;
const res = a % 2 == 1;

console.log(res);