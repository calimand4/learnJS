const A = 4;
const B = 5;
const C = 6;
const res = A < B ;
const res1 = B < C;
//A < B < C

console.log(res === true && res1 === true)