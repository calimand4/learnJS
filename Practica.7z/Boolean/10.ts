const A = 21;
const B = 14;
const res = A % 2 == 1;
const res1 = B % 2 == 1;

console.log(res !== res1 );