const A = 4;
const B = 1;
const res = A > 2;
const res1 = B <= 3;

console.log(res , res1);