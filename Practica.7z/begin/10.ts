const a = 10;
const b = 8;
const X = a + b;
const Y = a - b;
const Z = a * b;
const P = Math.pow(a , 2) / Math.pow(b , 2);

console.log(X , Y , Z , P);