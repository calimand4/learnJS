const a = 6;
const P = 4 * a;

console.log(P);