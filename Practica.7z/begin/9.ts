const a = 6;
const b = 8;
const X = Math.sqrt(a * b);

console.log(X);