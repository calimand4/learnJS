const a = 5;
const S = Math.pow(a , 2);

console.log(S);