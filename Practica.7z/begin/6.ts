const a = 2; 
const b = 3;
const c = 4;
const V = a * b * c;
const S = 2 * (a * b + b * c + a * c);

console.log(V , S);