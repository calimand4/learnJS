const a = 3;
const b = 7;
const X = (a + b) / 2;

console.log(X);