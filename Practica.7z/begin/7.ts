const R = 10;
const L = 2 * Math.PI * R;
const S = Math.PI * Math.pow(R , 2);

console.log(L , S);