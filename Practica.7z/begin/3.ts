const a = 3;
const b = 7;
const S = a*b;
const P = 2*(a+b);

console.log(S , P);
