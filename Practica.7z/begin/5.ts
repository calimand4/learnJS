const a = 5;
const V = Math.pow(a , 3);
const S = 6 * Math.pow(a , 2);

console.log(V  ,  S);