const d = 5;
const L = Math.PI * d;

console.log(L);